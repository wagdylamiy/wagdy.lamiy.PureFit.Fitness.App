import 'package:flutter/material.dart';

Widget dietError() {
  return const Center(child: Text('An error occurred'));
}
