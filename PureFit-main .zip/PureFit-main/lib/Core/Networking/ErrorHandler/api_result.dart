// abstract class ApiResult<T> with _$ApiResult<T> {


//   const factory ApiResult.success(T data) = Success<T>
//     const factory ApiResult.failuer(T data) = Failuer<T>

// }