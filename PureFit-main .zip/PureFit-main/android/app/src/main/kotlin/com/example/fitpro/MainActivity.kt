package com.example.PureFit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
